public class BasicsTest{
    public static void main(String[] args){
        Basics basics = new Basics();
        // int[] a = basics.counter();
        // System.out.println(a);

        // int[] b = basics.oddcounter();
        // System.out.println(b);

        // int c = basics.sumcounter();
        // System.out.println(c);

        int[] array = {1,3,5,7,9,11};
        // String d = basics.interatearray(array);
        // System.out.println(d);

        // int e = basics.max(array);
        // System.out.println(e);

        // double f = basics.average(array);
        // System.out.println(f);

        // int[] g = basics.oddarray();
        // System.out.println(g);

        // int[] h = basics.greater(array, 5);
        // System.out.println(h);

        // int[] i = basics.positive(array);
        // System.out.println(i);

        // int[] j = basics.allabove(array);
        // System.out.println(j);

        int[] k = basics.shift(array);
        System.out.println(k);

    }

}